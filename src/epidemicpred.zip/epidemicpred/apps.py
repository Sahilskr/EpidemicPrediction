from django.apps import AppConfig


class EpidemicpredConfig(AppConfig):
    name = 'epidemicpred'
