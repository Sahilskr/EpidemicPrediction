from django.http import HttpResponse
from django.shortcuts import render
from django.views.generic import ListView
from .models import City
from django.db.models import Q

# Create your views here.
def home(request,*args, **kwargs):
    return render(request,"index.html",{})

def about(request,*args, **kwargs):
    return render(request,"about.html",{})

def contact(request,*args, **kwargs):
    return render(request,"contact.html",{})

def helpline(request,*args, **kwargs):
    return render(request,"helpline.html",{})


class SearchResultsView(ListView):
    model = City
    template_name = 'tp.html'

    def get_queryset(self): # new
        query = self.request.GET.get('q')
        object_list = City.objects.filter(
        Q(name__icontains=query) | Q(state__icontains=query)
    )
        return object_list
